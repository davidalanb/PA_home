#import ImageGrab
from PIL import ImageGrab

'''
try:
    ImageGrab.grab().save('screen.png', "PNG")
except Exception as e:
    print(e)
    
try:
    ImageGrab.grab().save('screen.jpg', "JPEG")
except Exception as e:
    print(e)

'''