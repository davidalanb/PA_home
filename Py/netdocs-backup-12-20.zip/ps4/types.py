
print( type( 5 ))
print( type( 5.0 ))
print( type( '5' ))
print( type( True ))
print( type( (1,2)))
print( type( [1,2] ))

print( 1 + 2 )
print( '1' + '2' )
#print( 1 + '2' )

x = 1
y = '2'
y = int(y)
print( x + y )

a = '1'
print( a.isnumeric() )

