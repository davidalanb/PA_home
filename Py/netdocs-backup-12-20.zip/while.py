
# prints 0 to 9
for x in range(10):
    print( x )


# prints 0 to 9
x = 0
while( x < 10 ):
    print( x )
    x += 1


x = input()
while ( x ):
    print(x)
    x = input()

