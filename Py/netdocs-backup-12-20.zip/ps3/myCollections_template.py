'''
Program set 3 - myCollections
Name:

Implement these functions
'''

# prints members of list, one each on multiple lines
def print_lines( list ):
    None

# prints all the members of list on one line,
#	separated by the string in delim
def print_line( list, delim ):
    None

# prints a two-column (tab-separated) table
#	column 1 is n
 #	column 2 is a-sub-n
def print_table( list ):
    None

'''
the next two functions regard sequences & series.
See these links for more info:
http://www.purplemath.com/modules/series.htm
http://www.purplemath.com/modules/series3.htm
'''

# returns a list with the arithmetic series
#	a: starting value
#	b: common difference
# 	n: number of terms to return
def arithmetic( a, b, n ):
    None

# returns a list with the geometric series
#	a: starting value
#	b: common ratio
# 	n: number of terms to return
def geometric( a, b, n ):
    None

# returns the sum of the values in the given list
def my_sum( list ):
    None

# challenge problem: leave 'None' if you skip this one
# returns list containing a sequence
#	li: lower index
#	ui: upper index
#	foo: function defining sequence
def sequence( li, ui, foo ):
    None

# prints an n X n multiplication table
# starting at 1 and ending at n
def mult_table(n):
    None

# print a chess board using ASCII
def chess( rows, columns):
    None


