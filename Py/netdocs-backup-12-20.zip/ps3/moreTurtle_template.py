'''
Program set 3 - moreTurtle
Name:

Implement these functions
'''

import turtle

# draws an n-sided poly with side length s
def draw_poly(t, n, s):
    None

# draws the coordinates given as (x,y) tuples in list
def draw_coords( t, list ):
    None

# draws a chess board rows X cols with side length s
def draw_chess( t, rows, cols, s ):
    None

# draws a star with n points and width w
def draw_star( t, n, w ):
    None
