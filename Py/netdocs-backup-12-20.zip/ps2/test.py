
'''
from myMath import distance

p1 = (1, 2)
p2 = (3, 4)

print( distance( p1,p2 ))
'''

import myMath

p1 = (1, 2)
p2 = (3, 4)

print( myMath.distance( p1,p2 ))