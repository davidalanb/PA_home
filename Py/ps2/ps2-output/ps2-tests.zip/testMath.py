import myMath

print(myMath.distance((3,0), (8,5)))
print(myMath.circle_area(1))
print(myMath.quadratic(1, 3, 2))